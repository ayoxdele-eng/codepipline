package com.example.javaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaappApplicationTests {

	@Test
	void contextLoads() {
	}

}
