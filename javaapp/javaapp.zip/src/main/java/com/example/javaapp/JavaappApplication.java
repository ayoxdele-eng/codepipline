package com.example.javaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaappApplication.class, args);
	}

}
