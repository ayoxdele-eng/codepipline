#!/bin/bash
 
apt update -y  