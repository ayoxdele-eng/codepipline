#!/bin/bash

# Check if javaapp.service is running
if systemctl is-active --quiet javaapp.service; then
    # Stop the service
    systemctl stop javaapp.service
    echo "javaapp.service stopped."
else
    echo "javaapp.service is not running."
fi
