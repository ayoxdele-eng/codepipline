#!/bin/bash

# Start the service
systemctl start javaapp.service

# Check if the service started successfully
if systemctl is-active --quiet javaapp.service; then
    echo "javaapp.service started successfully."
else
    echo "Failed to start javaapp.service."
fi
